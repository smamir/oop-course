class Meters
{
    private:
        double length;
        double width;

    public:
        Meters(): length(0.0), width(0.0) {}
        Meters(double a, double b): length(a), width(b) {}

        double getLength()
        {
            return length;
        }
        double getWidth()
        {
            return width;
        }
        void display()
        {
            cout << "Length: " << length << " Meters" << endl;
            cout << "Width: " << width << " Meters" << endl;
        }

        Meters(Feet x)
        {
            length = x.getLength()/3.28;
            width = x.getWidth()/3.28;
        }

};
