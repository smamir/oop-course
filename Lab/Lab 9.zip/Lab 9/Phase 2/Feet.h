#include<iostream>
#include<cmath>

using namespace std;

class Feet
{
    private:
        double length;
        double width;

    public:
        Feet(): length(0.0), width(0.0) {}
        Feet(double a, double b): length(a), width(b) {}

        double getLength()
        {
            return length;
        }
        double getWidth()
        {
            return width;
        }
        void display()
        {
            cout << "Length: " << length << " Feet" << endl;
            cout << "Width: " << width << " Feet" << endl;
        }

        operator Meters()
        {
            length = length/3.28;
            width = width/3.28;

            return Meters(length,width);
        }


};
