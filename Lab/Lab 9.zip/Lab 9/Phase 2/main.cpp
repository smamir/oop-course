#include <iostream>
#include"Feet.h"
#include"Meters.h"

using namespace std;

int main()
{
    Feet a(12,12), c (24,36);

    Meters b(a);

    b.display();

    Meters d = (Meters) c;

    return 0;
}
