#include<iostream>
#include"Feet.h"

using namespace std;

int main()
{
    Feet a(24, 36);

    //a.display();
    double b = (double) a;

    cout << "Area in square inches: " << b << endl;

    double s = 20999;
    Feet c = s;
    c.display();

    return 0;
}
