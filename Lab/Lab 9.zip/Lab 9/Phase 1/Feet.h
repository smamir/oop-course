#include<iostream>
#include<cmath>
using namespace std;

class Feet
{
    private:
        double length;
        double width;

    public:
        Feet(): length(0.0), width(0.0) {}
        Feet(double a, double b): length(a), width(b) {}
        Feet(double area_sq_inches)
        {
            double area_sq_feet = (1.0/144.0)*area_sq_inches;
            length = sqrt(area_sq_feet);
            width = sqrt(area_sq_feet);
        }
        double getLength()
        {
            return length;
        }
        double getWidth()
        {
            return width;
        }
        void display()
        {
            cout << "Length: " << length << " Feet" << endl;
            cout << "Width: " << width << " Feet" << endl;
        }

        operator double()
        {
            double area = (length*12) * (width*12);
            return area;
        }

};
