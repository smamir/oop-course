#include<iostream>
using namespace std;

class point{
    private:
        INTEGER x;
        INTEGER y;
    public:
        point():x(0),y(0){
        }
        point(INTEGER a, INTEGER b): x(a), y(b){

        }
        ~point(){
        }
        point operator +(point p){
            INTEGER a = x + p.x;
            INTEGER b = y + p.y;
            return point(a,b);
        }
        point operator -(point p){
            INTEGER a = x - p.x;
            INTEGER b = y - p.y;
            return point(a,b);
        }
        bool operator >(point p){
            INTEGER a = (x*x + y*y);
            INTEGER b = (p.x*p.x + p.y*p.y);
            //a.display();
            //b.display();
            return (a>b)?true:false;
        }
        void display_me(){
            cout<<"This is display"<<endl;
            x.display();
            y.display();
            cout<<endl;
        }

};
