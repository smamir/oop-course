#include"integer.h"
#include"point.h"

int main(){
    point p1(8,5),p2(9,7);
    point p3;
    p3 = p1 + p2;
    p3.display_me();
    if(p1>p2){
        cout<<"p1 is greater or equal to p2"<<endl;
    }
    else{
        cout<<"p2 is greater or equal to p1"<<endl;
    }
    return 0;
}
