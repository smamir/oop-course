#include<iostream>
using namespace std;

class INTEGER{
    private:
        int value;

    public:
        INTEGER():value(0){
        }
        INTEGER(int a):value(a){

        }
        ~INTEGER(){
        }

        INTEGER operator +(INTEGER x){
            int a = value + x.value;
            return INTEGER(a);
        }
        INTEGER operator -(INTEGER x){
            int a = value - x.value;
            return INTEGER(a);
        }
        INTEGER operator *(INTEGER x){
            int a = value * x.value;
            return INTEGER(a);
        }
        INTEGER operator /(INTEGER x){
            int a = value / x.value;
            return INTEGER(a);
        }
        INTEGER operator %(INTEGER x){
            int a = value % x.value;
            return INTEGER(a);
        }

        void operator +=(INTEGER b){
            value = value + b.value;
        }
        void operator -=(INTEGER b){
            value = value - b.value;
        }
        void operator *=(INTEGER b){
            value = value * b.value;
        }
        void operator /=(INTEGER b){
            value = value / b.value;
        }
        bool operator >=(INTEGER b){
            if(value>=b.value){
                return true;
            }
            else{
                return false;
            }
        }
        bool operator <=(INTEGER b){
            if(value<=b.value){
                return true;
            }
            else{
                return false;
            }
        }
        bool operator ==(INTEGER b){
            if(value==b.value){
                return true;
            }
            else{
                return false;
            }
        }
        bool operator !=(INTEGER b){
            if(value!=b.value){
                return true;
            }
            else{
                return false;
            }
        }


        bool operator >(INTEGER b){
            if(value>b.value){
                return true;
            }
            else
                return false;

        }
        bool operator <(INTEGER b){
            if(value<b.value){
                return true;
            }
            else
                return false;

        }
        int operator ++(){
            return ++value;
        }
        int operator ++(int){
            return value++;
        }

        int operator --(){
            return --value;
        }
        int operator --(int){
            return value--;
        }

        void display(){
            cout<<value<<" ";
        }
};
